create view lastdate as
SELECT Cliente.nome as Cliente,  max(Pedido.dt) as DataUltimaCompra, 
	sum(Pagamento.Total) as ValorPago, Prato.nome as Item
from Cliente 
left join Pedido on Cliente.CPF = Pedido.Cliente_CPF 
left join Pagamento on Pagamento.ID_Pedido = Pedido.ID
left join ItemPedido on ItemPedido.ID_Pedido = Pedido.ID
left join Prato on Prato.ID_tipo = ItemPedido.ID_Pedido
where Pedido.dt is not null
group by Cliente.nome, Pedido.dt;

select * from lastdate;

