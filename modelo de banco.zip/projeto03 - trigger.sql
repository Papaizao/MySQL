-- TRIGGER PARA REALIZAR PEDIDO
delimiter //
	create trigger pedido before insert on ItemPedido for each row
		begin			
            declare q float;          
        
            select quantidade into q from Prato where Prato.ID =new.ID_Prato; 
            
            if(new.quantidade > q)
				then            
				signal sqlstate '99999' set message_text = 'Saldo insuficiente';		
			end if;          
end//  
-- TRIGGER PARA INSERIR PAGAR
delimiter //
	create trigger pago after insert on Pagamento for each row
		begin	          
			declare id1 int;
            
            select ID into id1 from Pedido where new.ID_Pedido = id1;
            
            update Pedido set status = "Pago" where ID = new.ID_Pedido;				
					
end // 

-- TRIGGER PARA DELETE PAGAR
delimiter //
	create trigger naopago after delete on Pagamento for each row
		begin	          
			declare id1 int;
            
            select ID into id1 from Pedido where old.ID_Pedido = id1;
            
            if(id1 is null)
				then
                update Pedido set status = "Em aberto" where ID = old.ID_Pedido;	
			else
				signal sqlstate '99998' set message_text = 'Ja existe um Pagamento';
			end if;
end // 
-- TRIGGER PARA INSERT LOG PAGAMENTO
delimiter //
	create trigger logiPA after insert on Pagamento for each row
		begin			
			declare msg  varchar(255);
            declare id int default 0;
           
            select max(Numero) into id from Log;
            
            set msg = concat('O registro ', new.ID, ' da tabela Pagamento foi inserido por ', user());
            
            insert into Log (Numero, Ocorrencia, Data) values(id+1, msg, current_date());		
end // 
  -- TRIGGER PARA UPDATE LOG PAGAMENTO     
    delimiter //
	create trigger loguPA after update on Pagamento for each row
		begin			
			declare msg  varchar(255);
            declare id int default 0;
           
            select max(Numero) into id from Log;
            
            set msg = concat('O registro ', old.ID, ' da tabela Pagamento foi alterado por ', user());
            
            insert into Log (Numero, Ocorrencia, Data) values(id+1, msg, current_date());		
end // 
-- TRIGGER PARA DELETE LOG PAGAMENTO
   delimiter //
	create trigger logdPA after delete on Pagamento for each row
		begin			
			declare msg  varchar(255);
            declare id int default 0;
           
            select max(Numero) into id from Log;
            
            set msg = concat('O registro ', old.ID, ' da tabela Pagamento foi deletado por ', user());
            
            insert into Log (Numero, Ocorrencia, Data) values(id+1, msg, current_date());		
end // 
-- TRIGGER PARA LOG DE INSERT CLIENTE
delimiter //
	create trigger logiC after insert on Cliente for each row
		begin			
			declare msg  varchar(255);
            declare id int default 0;
           
            select max(Numero) into id from Log;
            
            set msg = concat('O registro ', new.CPF, ' da tabela Cliente foi inserido por ', user());
            
            insert into Log (Numero, Ocorrencia, Data) values(id+1, msg, current_date());		
end // 
  -- TRIGGER PARA UPDATE LOG CLIENTE     
    delimiter //
	create trigger loguC after update on Cliente for each row
		begin			
			declare msg  varchar(255);
            declare id int default 0;
           
            select max(Numero) into id from Log;
            
            set msg = concat('O registro ', old.CPF, ' da tabela Cliente foi alterado por ', user());
            
            insert into Log (Numero, Ocorrencia, Data) values(id+1, msg, current_date());		
end // 
-- TRIGGER PARA DELETE LOG CLIENTE
   delimiter //
	create trigger logdC after delete on Cliente for each row
		begin			
			declare msg  varchar(255);
            declare id int default 0;
           
            select max(Numero) into id from Log;
            
            set msg = concat('O registro ', old.CPF, ' da tabela Cliente foi deletado por ', user());
            
            insert into Log (Numero, Ocorrencia, Data) values(id+1, msg, current_date());		
end // 

-- TRIGGER PARA LOG DE INSERT MESA
delimiter //
	create trigger logiM after insert on Mesa for each row
		begin			
			declare msg  varchar(255);
            declare id int default 0;
           
            select max(Numero) into id from Log;
            
            set msg = concat('O registro ', new.numero, ' da tabela Mesa foi inserido por ', user());
            
            insert into Log (Numero, Ocorrencia, Data) values(id+1, msg, current_date());		
end // 
  -- TRIGGER PARA UPDATE LOG MESA     
    delimiter //
	create trigger loguM after update on Mesa for each row
		begin			
			declare msg  varchar(255);
            declare id int default 0;
           
            select max(Numero) into id from Log;
            
            set msg = concat('O registro ', old.numero, ' da tabela Mesa foi alterado por ', user());
            
            insert into Log (Numero, Ocorrencia, Data) values(id+1, msg, current_date());		
end // 
-- TRIGGER PARA DELETE LOG MESA
   delimiter //
	create trigger logdM after delete on Mesa for each row
		begin			
			declare msg  varchar(255);
            declare id int default 0;
           
            select max(Numero) into id from Log;
            
            set msg = concat('O registro ', old.numero, ' da tabela Mesa foi deletado por ', user());
            
            insert into Log (Numero, Ocorrencia, Data) values(id+1, msg, current_date());		
end // 

-- TRIGGER PARA LOG DE INSERT GERENTE
delimiter //
	create trigger logiG after insert on Gerente for each row
		begin			
			declare msg  varchar(255);
            declare id int default 0;
           
            select max(Numero) into id from Log;
            
            set msg = concat('O registro ', new.CPF, ' da tabela Gerente foi inserido por ', user());
            
            insert into Log (Numero, Ocorrencia, Data) values(id+1, msg, current_date());		
end // 
  -- TRIGGER PARA UPDATE LOG GERENTE     
    delimiter //
	create trigger loguG after update on Gerente for each row
		begin			
			declare msg  varchar(255);
            declare id int default 0;
           
            select max(Numero) into id from Log;
            
            set msg = concat('O registro ', old.CPF, ' da tabela Gerente foi alterado por ', user());
            
            insert into Log (Numero, Ocorrencia, Data) values(id+1, msg, current_date());		
end // 
-- TRIGGER PARA DELETE LOG GERENTE
   delimiter //
	create trigger logdG after delete on Gerente for each row
		begin			
			declare msg  varchar(255);
            declare id int default 0;
           
            select max(Numero) into id from Log;
            
            set msg = concat('O registro ', old.CPF, ' da tabela Gerente foi deletado por ', user());
            
            insert into Log (Numero, Ocorrencia, Data) values(id+1, msg, current_date());		
end // 
-- TRIGGER PARA INSERT LOG FUNCIONARIO
delimiter //
	create trigger logiF after insert on Funcionario for each row
		begin			
			declare msg  varchar(255);
            declare id int default 0;
           
            select max(Numero) into id from Log;
            
            set msg = concat('O registro ', new.CPF, ' da tabela Funcionario foi inserido por ', user());
            
            insert into Log (Numero, Ocorrencia, Data) values(id+1, msg, current_date());		
end // 
  -- TRIGGER PARA UPDATE LOG FUNCIONARIO    
    delimiter //
	create trigger loguF after update on Funcionario for each row
		begin			
			declare msg  varchar(255);
            declare id int default 0;
           
            select max(Numero) into id from Log;
            
            set msg = concat('O registro ', old.CPF, ' da tabela Funcionario foi alterado por ', user());
            
            insert into Log (Numero, Ocorrencia, Data) values(id+1, msg, current_date());		
end // 
-- TRIGGER PARA DELETE LOG FUNCIONARIO
   delimiter //
	create trigger logdF after delete on Funcionario for each row
		begin			
			declare msg  varchar(255);
            declare id int default 0;
           
            select max(Numero) into id from Log;
            
            set msg = concat('O registro ', old.CPF, ' da tabela Funcionario foi deletado por ', user());
            
            insert into Log (Numero, Ocorrencia, Data) values(id+1, msg, current_date());		
end // 
 -- TRIGGER PARA INSERT LOG PRATO
delimiter //
	create trigger logiPR after insert on Prato for each row
		begin			
			declare msg  varchar(255);
            declare id int default 0;
           
            select max(Numero) into id from Log;
            
            set msg = concat('O registro ', new.ID, ' da tabela Prato foi inserido por ', user());
            
            insert into Log (Numero, Ocorrencia, Data) values(id+1, msg, current_date());		
end // 
  -- TRIGGER PARA UPDATE LOG PRATO     
    delimiter //
	create trigger loguPR after update on Prato for each row
		begin			
			declare msg  varchar(255);
            declare id int default 0;
           
            select max(Numero) into id from Log;
            
            set msg = concat('O registro ', old.ID, ' da tabela Prato foi alterado por ', user());
            
            insert into Log (Numero, Ocorrencia, Data) values(id+1, msg, current_date());		
end // 
-- TRIGGER PARA DELETE LOG PRATO
   delimiter //
	create trigger logdPR after delete on Prato for each row
		begin			
			declare msg  varchar(255);
            declare id int default 0;
           
            select max(Numero) into id from Log;
            
            set msg = concat('O registro ', old.ID, ' da tabela Prato foi deletado por ', user());
            
            insert into Log (Numero, Ocorrencia, Data) values(id+1, msg, current_date());		
end // 

-- TRIGGER PARA INSERT LOG TIPO
delimiter //
	create trigger logiT after insert on Tipo for each row
		begin			
			declare msg  varchar(255);
            declare id int default 0;
           
            select max(Numero) into id from Log;
            
            set msg = concat('O registro ', new.ID, ' da tabela Tipo foi inserido por ', user());
            
            insert into Log (Numero, Ocorrencia, Data) values(id+1, msg, current_date());		
end // 
  -- TRIGGER PARA UPDATE LOG TIPO     
    delimiter //
	create trigger loguT after update on Tipo for each row
		begin			
			declare msg  varchar(255);
            declare id int default 0;
           
            select max(Numero) into id from Log;
            
            set msg = concat('O registro ', old.ID, ' da tabela Tipo foi alterado por ', user());
            
            insert into Log (Numero, Ocorrencia, Data) values(id+1, msg, current_date());		
end // 
-- TRIGGER PARA DELETE LOG TIPO
   delimiter //
	create trigger logdT after delete on Tipo for each row
		begin			
			declare msg  varchar(255);
            declare id int default 0;
           
            select max(Numero) into id from Log;
            
            set msg = concat('O registro ', old.ID, ' da tabela Tipo foi deletado por ', user());
            
            insert into Log (Numero, Ocorrencia, Data) values(id+1, msg, current_date());		
end // 
	-- TRIGGER PARA INSERT LOG PEDIDO
delimiter //
	create trigger logiP after insert on Pedido for each row
		begin			
			declare msg  varchar(255);
            declare id int default 0;
           
            select max(Numero) into id from Log;
            
            set msg = concat('O registro ', new.ID, ' da tabela Pedido foi inserido por ', user());
            
            insert into Log (Numero, Ocorrencia, Data) values(id+1, msg, current_date());		
end // 
  -- TRIGGER PARA UPDATE LOG PEDIDO   
    delimiter //
	create trigger loguP after update on Pedido for each row
		begin			
			declare msg  varchar(255);
            declare id int default 0;
           
            select max(Numero) into id from Log;
            
            set msg = concat('O registro ', old.ID, ' da tabela Pedido foi alterado por ', user());
            
            insert into Log (Numero, Ocorrencia, Data) values(id+1, msg, current_date());		
end // 
-- TRIGGER PARA DELETE LOG PEDIDO
   delimiter //
	create trigger logdP after delete on Pedido for each row
		begin			
			declare msg  varchar(255);
            declare id int default 0;
           
            select max(Numero) into id from Log;
            
            set msg = concat('O registro ', old.ID, ' da tabela Pedido foi deletado por ', user());
            
            insert into Log (Numero, Ocorrencia, Data) values(id+1, msg, current_date());		
end // 

 -- TRIGGER PARA INSERT LOG ITEMPEDIDO
delimiter //
	create trigger logiI after insert on ItemPedido for each row
		begin			
			declare msg  varchar(255);
            declare id int default 0;
           
            select max(Numero) into id from Log;
            
            set msg = concat('O registro ', new.ID_Pedido, ' da tabela ItemPedido foi inserido por ', user());
            
            insert into Log (Numero, Ocorrencia, Data) values(id+1, msg, current_date());		
end // 
  -- TRIGGER PARA UPDATE LOG ItemPedido    
    delimiter //
	create trigger loguI after update on ItemPedido for each row
		begin			
			declare msg  varchar(255);
            declare id int default 0;
           
            select max(Numero) into id from Log;
            
            set msg = concat('O registro ', old.ID_Pedido, ' da tabela ItemPedido foi alterado por ', user());
            
            insert into Log (Numero, Ocorrencia, Data) values(id+1, msg, current_date());		
end // 
-- TRIGGER PARA DELETE LOG ItemPedido
   delimiter //
	create trigger logdI after delete on ItemPedido for each row
		begin			
			declare msg  varchar(255);
            declare id int default 0;
           
            select max(Numero) into id from Log;
            
            set msg = concat('O registro ', old.ID_Pedido, ' da tabela ItemPedido foi deletado por ', user());
            
            insert into Log (Numero, Ocorrencia, Data) values(id+1, msg, current_date());		
end // 