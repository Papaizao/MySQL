
  
-- PROCEDURE PARA INSERIR GERENTE

delimiter //
create procedure inserirG (in CPF1 int, in nome1 varchar(40))
begin

declare nome2 varchar(40);
declare CPF2 int;
select nome into nome2 from Gerente where nome1 = nome2;
select CPF into CPF2 from Gerente where CPF1 = CPF2;

if (CPF2 is null)
	then
	insert into Gerente (CPF, nome)values(CPF1, nome1);
end if;
select * from Gerente;
end//
-- PROCEDURE PARA INSERIR TIPO PRATO

delimiter //
create procedure inserirT (in id1 int, in nome1 varchar(40))
	begin
		
		declare ID2 int default 0;		
            
		select ID into ID2 from Tipo where id1 = ID2;		

		if(ID2 = 0)
			then
				insert into Tipo (ID, descricao) values (id1, nome1);
		else
			update Tipo set descricao = nome1 where ID = id2;
end if;
select * from Tipo;
end//

-- PROCEDURE PARA INSERIR MESAS
delimiter //
create procedure inserirM (in numero1 int, in cadeira1 varchar(40))
	begin

		declare cadeira2 varchar(40);		
        declare id2 int;

		select numero into id2 from Mesa where numero1 = id2;
		select cadeiras into cadeira2 from Mesa where cadeira1 = cadeira2;		

		if (id2 is null)
			then
			insert into Mesa (numero, cadeiras)values(numero1, cadeira1);
		else
			update Mesa set cadeiras = cadeira1 where id2 = numero1;
		end if;
       
		select * from Mesa;
end//

-- PROCEDURE PARA INSERIR CLIENTE

delimiter //
create procedure inserirC (in CPF1 int, in nome1 varchar(40), in mesa1 boolean, mesa_numero1 int)
	begin

	declare CPF2 int;
	
    select CPF into CPF2 from Cliente where CPF1 = CPF2;

	if(CPF2 is null)
		then
		insert into Cliente (CPF, nome, comMesa, Mesa_numero)values(CPF1, nome1, mesa1, mesa_numero1);
	else
		update Cliente set nome = nome1, comMesa = comMesa1, Mesa_numero = mesa_numero1 where CPF = CPF1;
        
	end if;
	select * from Cliente;
end//

-- PROCEDURE PARA INSERIR FUNCIONARIO
delimiter //
create procedure inserirF (in CPF1 int, in nome1 varchar(40), in gerente1 int)
	begin

		declare CPF2 int;

		select CPF into CPF2 from Funcionario where CPF1 = CPF2;

		if (CPF2 is null)
			then
			insert into Funcionario (CPF, nome, Gerente)values(CPF1, nome1, gerente1);
		else
			update Funcionario set nome = nome1, Gerente = gerente1 where CPF = CPF1;
		end if;
		select * from Funcionario;
end//


-- PROCEDURE PARA INSERIR PRATO

delimiter //
create procedure inserirPR (in id1 int, in nome1 varchar(40), in descricao1 varchar(40), in preco1 float, quantidade1 float, in tipo1 int)
	begin

	declare id2 int;	

	select ID into id2 from Tipo where id1 = id2;	

	if (id2 is null)
		then
		insert into Prato (ID, nome, descricao, preco, quantidade, ID_tipo) values(id1,nome1, descricao1, preco1, quantidade1, tipo1);
	else
		update Prato set nome = nome1, descricao= descricao1, preco = preco1, quantidade = quantidade1, ID_tipo = tipo1 where ID = id1;	
	end if;
	select * from Prato;
end//

	-- PROCEDURE PARA INSERIR PEDIDO
delimiter //
create procedure inserirP (in id1 int, in status1 varchar(40), in CPF1 int, in FCPF1 int, dt1 date)
begin
	declare id2 int;	
    
	select ID into id2 from Pedido where id1 = id2;   

	if (id2 is null) 
		then
		insert into Pedido (ID,status, Cliente_CPF, f_CPF, dt)values(id1,"Em aberto", CPF1, FCPF1, dt1);
	else
		update Pedido set status = status1, Cliente_CPF = CPF1, f_CPF = FCPF1, dt = dt1 where ID = id1;
	end if;

select * from Pedido;
end//
 -- PROCEDURE PARA INSERIR ITEM PEDIDO
 delimiter // 
create procedure inserirI (in id1 int, in id2 int, in qtd float)
	begin

		declare id3 int;
		declare id4 int;

		select ID_Pedido into id3 from ItemPedido where id1 = id3;		

		if (id3 is null)
			then
			insert into ItemPedido (ID_Pedido, ID_Prato, quantidade) values(id1, id2, qtd);
		else
			update ItemPedido set quantidade = qtd where ID_Pedido = id1 and ID_Prato = id2;
end if;
   
select * from ItemPedido;
end // 
--  PROCEDURE PARA INSERIR PAGAMENTO
  delimiter //
	create procedure inserirPA (in t1 float, in d1 date, in id2 int, in id1 int)
		begin
			declare id3 int;        
			
			select ID into id3 from Pagamento where id3 = id2;
	
        if (id3 is null)
			then 
			insert into Pagamento (Total, dat, ID, ID_Pedido) values(t1, d1, id2, id1);
		else
			update Pagamento set Total = t1, dat = d1, ID_Pedido = id2 where ID = id1;
		
        end if;
		select * from Pagamento;
end // 

call inserirG(1212, "Rob");
call inserirT(1,"salada");
call inserirM(1,4);
call inserirC(1234,"MANOO", true, 1);
call inserirF(1,"Leo", 1212);
call inserirPR(1,"Cerveja", "cevada", 5.6, 2, 1);
call inserirP(2, "Em aberto", 1234, 1, current_date());
call inserirI(1, 1, 2);
call inserirPA(30, current_date(),2,2);
select * from Pedido
select * from Pagamento