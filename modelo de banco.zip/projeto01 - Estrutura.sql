drop database if exists projeto;
CREATE database if not exists projeto;
USE projeto ;

-- -----------------------------------------------------
-- Table `mydb`.`Mesa`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS Mesa (
  numero INT NOT NULL,
  cadeiras VARCHAR(45) NOT NULL, 
  PRIMARY KEY (numero));
  -- -----------------------------------------------------
-- Table `mydb`.`Cliente`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS Cliente(
  CPF INT NOT NULL,
  nome VARCHAR(45) NOT NULL,
  comMesa boolean ,
  Mesa_numero INT,
  PRIMARY KEY (CPF),
  FOREIGN KEY (Mesa_numero) REFERENCES Mesa (numero));
  
  -- TABELA TIPO
   CREATE TABLE IF NOT EXISTS Tipo(
  ID INT NOT NULL, 
  descricao VARCHAR(45) not null, 
  PRIMARY KEY (ID));
  
-- TABLE PRATO
CREATE TABLE IF NOT EXISTS Prato(
  ID INT NOT NULL,
  nome VARCHAR(45) NOT NULL,
  descricao VARCHAR(45) not null,
  preco float not null,
  quantidade float,  
  ID_tipo int not null,
  foreign key (ID_tipo) references Tipo(ID),
  PRIMARY KEY (ID));

-- -----------------------------------------------------
-- Table `mydb`.`Gerente`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS Gerente(
  CPF INT NOT NULL,
  nome VARCHAR(45) NOT NULL,
  PRIMARY KEY (CPF));
  
 -- -----------------------------------------------------
-- Table `mydb`.`Funcionario`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS Funcionario (
  CPF INT NOT NULL,
  nome VARCHAR(45) NOT NULL,
  Gerente int not null,
  PRIMARY KEY (CPF),
  foreign key (Gerente) references Gerente(CPF));

  -- -----------------------------------------------------
-- Table `mydb`.`Pedidos`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS Pedido (
  ID INT NOT NULL,    
  status varchar(40),
  Cliente_CPF int not null,
  f_CPF int not null,
  dt date,
  PRIMARY KEY (ID),
  foreign key(f_CPF) references Funcionario (CPF),
  foreign key(Cliente_CPF) references Cliente (CPF));
 
    -- -----------------------------------------------------
-- Table `mydb`.`Item do Pedido`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS ItemPedido(
 ID_Pedido INT NOT NULL,
 ID_Prato int not null,
 quantidade float not null,
 foreign key(ID_Prato) references Prato(ID),
 foreign key (ID_Pedido) references Pedido(ID),
 primary key(ID_Pedido, ID_Prato));

   -- -----------------------------------------------------
-- Table `mydb`.`Pagamento`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS Pagamento (
  Total FLOAT NOT NULL,
  dat date NOT NULL,
  ID INT NOT NULL,
  ID_Pedido int not null, 
  PRIMARY KEY (ID),
  foreign key(ID_Pedido) references Pedido(ID));  

-- TABLE LOG

create table Log (
Numero int not null primary key,
Ocorrencia varchar(500),
Data date);

insert into Log values(1, "Criacao do banco", current_date())
